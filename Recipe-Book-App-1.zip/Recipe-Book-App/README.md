# Recipe Book App

This project matches the Recipe Book App requirement:
- React frontend with useState and useEffect
- Node.js + Express backend
- MongoDB + Mongoose
- CRUD API
- Mongoose required-field validation
- Add, Edit and Delete recipes

## Run Backend

Open a terminal in `backend`:

```bash
npm install
npm run dev
```

Backend runs at:
http://localhost:5000

## Run Frontend

Open another terminal in `frontend`:

```bash
npm install
npm run dev
```

Frontend normally runs at:
http://localhost:5173

## MongoDB

The default `.env` uses:

MONGO_URI=mongodb://127.0.0.1:27017/recipeBook

Make sure MongoDB is running locally, or replace MONGO_URI with your MongoDB Atlas connection string.
