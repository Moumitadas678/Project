import { useEffect, useState } from "react";
import axios from "axios";

const API_URL = "http://localhost:5000/recipes";

function App() {
  const [recipes, setRecipes] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    ingredients: "",
    cookTime: "",
    category: ""
  });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchRecipes();
  }, []);

  const fetchRecipes = async () => {
    try {
      const response = await axios.get(API_URL);
      setRecipes(response.data);
    } catch (error) {
      console.error(error);
      alert("Could not load recipes. Make sure the backend and MongoDB are running.");
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name || !formData.ingredients || !formData.cookTime || !formData.category) {
      alert("Please fill all fields.");
      return;
    }

    try {
      if (editingId) {
        const response = await axios.put(`${API_URL}/${editingId}`, formData);
        setRecipes(recipes.map((recipe) =>
          recipe._id === editingId ? response.data : recipe
        ));
        alert("Recipe updated successfully.");
        setEditingId(null);
      } else {
        const response = await axios.post(API_URL, formData);
        setRecipes([response.data, ...recipes]);
        alert("Recipe added successfully.");
      }

      setFormData({ name: "", ingredients: "", cookTime: "", category: "" });
    } catch (error) {
      console.error(error);
      alert("Something went wrong.");
    }
  };

  const handleEdit = (recipe) => {
    setFormData({
      name: recipe.name,
      ingredients: recipe.ingredients,
      cookTime: recipe.cookTime,
      category: recipe.category
    });
    setEditingId(recipe._id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this recipe?")) return;

    try {
      await axios.delete(`${API_URL}/${id}`);
      setRecipes(recipes.filter((recipe) => recipe._id !== id));
      alert("Recipe deleted successfully.");
    } catch (error) {
      console.error(error);
      alert("Could not delete recipe.");
    }
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormData({ name: "", ingredients: "", cookTime: "", category: "" });
  };

  return (
    <div className="app">
      <header className="header">
        <h1>🍴 Recipe Book</h1>
        <p>Manage your favourite recipes</p>
      </header>

      <main className="container">
        <section className="form-section">
          <h2>{editingId ? "Edit Recipe" : "Add New Recipe"}</h2>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Recipe Name</label>
              <input
                type="text"
                name="name"
                placeholder="Enter recipe name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Ingredients</label>
              <textarea
                name="ingredients"
                placeholder="Enter ingredients"
                value={formData.ingredients}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Cooking Time</label>
              <input
                type="text"
                name="cookTime"
                placeholder="Example: 30 minutes"
                value={formData.cookTime}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
              >
                <option value="">Select category</option>
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Dinner">Dinner</option>
                <option value="Dessert">Dessert</option>
                <option value="Snacks">Snacks</option>
                <option value="Drinks">Drinks</option>
              </select>
            </div>

            <div className="button-group">
              <button type="submit" className="submit-btn">
                {editingId ? "Update Recipe" : "Add Recipe"}
              </button>

              {editingId && (
                <button type="button" className="cancel-btn" onClick={handleCancel}>
                  Cancel
                </button>
              )}
            </div>
          </form>
        </section>

        <section className="recipe-section">
          <div className="section-title">
            <h2>All Recipes</h2>
            <span>{recipes.length} Recipes</span>
          </div>

          {recipes.length === 0 ? (
            <div className="empty">
              <h3>No recipes found</h3>
              <p>Add your first recipe using the form above.</p>
            </div>
          ) : (
            <div className="recipe-grid">
              {recipes.map((recipe) => (
                <div className="recipe-card" key={recipe._id}>
                  <div className="recipe-card-header">
                    <h3>{recipe.name}</h3>
                    <span className="category">{recipe.category}</span>
                  </div>

                  <div className="recipe-info">
                    <p><strong>Ingredients:</strong></p>
                    <p>{recipe.ingredients}</p>
                    <p><strong>Cooking Time:</strong> {recipe.cookTime}</p>
                  </div>

                  <div className="card-buttons">
                    <button className="edit-btn" onClick={() => handleEdit(recipe)}>
                      Edit
                    </button>
                    <button className="delete-btn" onClick={() => handleDelete(recipe._id)}>
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      <footer>
        <p>Recipe Book App © 2026</p>
      </footer>
    </div>
  );
}

export default App;