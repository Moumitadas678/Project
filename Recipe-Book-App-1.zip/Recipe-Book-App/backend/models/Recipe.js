const mongoose = require("mongoose");

const recipeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Recipe name is required"],
      trim: true
    },
    ingredients: {
      type: String,
      required: [true, "Ingredients are required"],
      trim: true
    },
    cookTime: {
      type: String,
      required: [true, "Cooking time is required"],
      trim: true
    },
    category: {
      type: String,
      required: [true, "Category is required"],
      trim: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Recipe", recipeSchema);